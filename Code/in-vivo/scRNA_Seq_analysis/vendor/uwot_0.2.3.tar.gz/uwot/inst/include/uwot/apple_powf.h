#ifndef UWOT_APPLE_POWF_H
#define UWOT_APPLE_POWF_H

#include <cmath>
#include <cstdint>
#include <cstring>

#include "apple_powf_exp_data.inc"
#include "apple_powf_log_data.inc"

namespace uwot {

template <typename To, typename From>
inline auto apple_powf_bit_cast(const From &value) -> To {
  static_assert(sizeof(To) == sizeof(From), "bit cast size mismatch");
  To result;
  std::memcpy(&result, &value, sizeof(result));
  return result;
}

inline auto apple_powf_load_double(const unsigned char *address) -> double {
  double result;
  std::memcpy(&result, address, sizeof(result));
  return result;
}

inline auto apple_powf_load_uint64(const unsigned char *address)
    -> std::uint64_t {
  std::uint64_t result;
  std::memcpy(&result, address, sizeof(result));
  return result;
}

// Reproduces the normal, positive-input path of Apple libSystem powf. UMAP's
// squared distances always take this path. Other inputs retain std::pow
// semantics through the fallback below.
inline auto apple_powf_compat(float x, float y) -> float {
  if (!(x > 0.0f) || !std::isfinite(x) || !std::isfinite(y) || y == 0.0f) {
    return std::pow(x, y);
  }

  constexpr std::uint32_t offset = 0x3f338000u;
  const auto ix = apple_powf_bit_cast<std::uint32_t>(x);
  // UMAP clamps squared distances to FLT_EPSILON, so subnormals never reach
  // this compatibility path.
  if (ix < 0x00800000u) {
    return std::pow(x, y);
  }

  const std::uint32_t temporary = ix - offset;
  const std::uint32_t index = (temporary >> 16) & 0x7fu;
  const std::uint32_t top = temporary & 0xff800000u;
  const std::uint32_t normalized_bits = ix - top;
  const std::int32_t exponent = static_cast<std::int32_t>(top) >> 16;
  const float normalized_float =
      apple_powf_bit_cast<float>(normalized_bits);
  const double normalized = static_cast<double>(normalized_float);

  const unsigned char *log_entry = apple_powf_log_data + 32 + index * 16;
  const double invc = apple_powf_load_double(log_entry);
  const double logc = apple_powf_load_double(log_entry + 8);
  const double r = std::fma(normalized, invc, -1.0);
  const double y0 = logc + static_cast<double>(exponent);
  const double r2 = r * r;
  double first = std::fma(
      r, apple_powf_load_double(apple_powf_log_data),
      apple_powf_load_double(apple_powf_log_data + 8));
  const double second = std::fma(
      r, apple_powf_load_double(apple_powf_log_data + 16),
      apple_powf_load_double(apple_powf_log_data + 24));
  first = std::fma(first, r2, second);
  const double log2_scaled = std::fma(first, r, y0);

  double ylogx = static_cast<double>(y) * log2_scaled;
  ylogx = std::fmin(ylogx, 32768.0);
  ylogx = std::fmax(ylogx, -32768.0);
  const double rounded = std::round(ylogx);
  const std::int64_t integer = static_cast<std::int64_t>(std::llround(ylogx));
  const double remainder = ylogx - rounded;

  const auto table_index = static_cast<std::uint64_t>(integer) & 0x7fu;
  std::uint64_t scale_bits = apple_powf_load_uint64(
      apple_powf_exp_data + 16 + table_index * 8);
  scale_bits += static_cast<std::uint64_t>(integer) << 45;
  const double scale = apple_powf_bit_cast<double>(scale_bits);
  double polynomial = std::fma(
      apple_powf_load_double(apple_powf_exp_data), remainder,
      apple_powf_load_double(apple_powf_exp_data + 8));
  polynomial *= remainder;
  return static_cast<float>(std::fma(polynomial, scale, scale));
}

} // namespace uwot

#endif // UWOT_APPLE_POWF_H
