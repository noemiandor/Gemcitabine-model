# Reproduce the active macOS arm64e libsystem_m log10 implementation while
# preserving the attributes that base::log10 keeps on numeric arrays/vectors.
log10 <- function(x) {
  original_attributes <- attributes(x)
  result <- apple_current_log10_numeric_cpp(as.numeric(x))
  attributes(result) <- original_attributes
  result
}

# Reproduce the double-precision accumulation used by macOS R, where
# capabilities("long.double") is false. Linux R accumulates var() in long
# double and changes the density bandwidth by a few ULPs.
apple_r451_var_double <- function(x) {
  n <- length(x)
  total <- 0
  for (value in x) total <- total + value
  center <- total / n
  if (is.finite(center)) {
    correction <- 0
    for (value in x) correction <- correction + (value - center)
    center <- center + correction / n
  }
  total <- 0
  for (value in x) {
    difference <- value - center
    total <- total + difference * difference
  }
  total / (n - 1L)
}

apple_r451_bw_nrd <- function(x) {
  quartiles <- stats::quantile(x, c(0.25, 0.75))
  robust_scale <- (quartiles[[2L]] - quartiles[[1L]]) / 1.34
  1.06 * min(sqrt(apple_r451_var_double(x)), robust_scale) *
    length(x)^(-1 / 5)
}

# stats::density() is compiled with contracted multiply-add operations in the
# Apple Silicon R 4.5.1 build that produced the reference object. The Linux
# build does not contract the same expressions. This implementation preserves
# the R 4.5.1 algorithm while routing those components through deterministic
# compatibility helpers.
apple_r451_density <- function(x, bw = apple_r451_bw_nrd(x), n = 512L,
                               cut = 3, ext = 4) {
  n_user <- n
  n <- max(n, 512L)
  if (n > 512L) n <- 2^ceiling(log2(n))

  from <- min(x) - cut * bw
  to <- max(x) + cut * bw
  lower <- from - ext * bw
  upper <- to + ext * bw

  binned <- apple_r451_bindist_equal_numeric_cpp(x, lower, upper, n)
  kernel_coordinates <- apple_r451_seq_numeric_cpp(
    0,
    ((2L * n - 1) / (n - 1)) * (upper - lower),
    2L * n
  )
  kernel_coordinates[(n + 2L):(2L * n)] <- -kernel_coordinates[n:2L]
  kernel_values <- stats::dnorm(kernel_coordinates, sd = bw)
  fft_compat <- function(values, inverse = FALSE) {
    apple_r451_fft_numeric_cpp(as.complex(values), inverse)
  }
  convolution <- fft_compat(
    fft_compat(binned) * Conj(fft_compat(kernel_values)),
    inverse = TRUE
  )
  convolution <- pmax.int(0, Re(convolution)[seq_len(n)] / length(binned))

  source_coordinates <- apple_r451_seq_numeric_cpp(lower, upper, n)
  output_coordinates <- apple_r451_seq_numeric_cpp(from, to, n_user)
  list(
    x = output_coordinates,
    y = apple_r451_approx_linear_numeric_cpp(
      source_coordinates,
      convolution,
      output_coordinates
    ),
    bw = bw
  )
}

apple_r451_density_sampling_probability <- function(x) {
  estimate <- apple_r451_density(x)
  1 / (
    apple_r451_approx_linear_numeric_cpp(estimate$x, estimate$y, x) +
      .Machine$double.eps
  )
}
