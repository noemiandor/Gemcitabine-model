/* Diagnostic compatibility implementation reconstructed from the active
 * macOS arm64e libsystem_m exp routine. Not part of the production source.
 */
#ifndef SCT_APPLE_CURRENT_EXP_COMPAT_H
#define SCT_APPLE_CURRENT_EXP_COMPAT_H
#include <cmath>
#include <cstdint>
#include <cstring>
namespace sct_compat {
inline double from_bits(std::uint64_t bits) {
  double value;
  std::memcpy(&value, &bits, sizeof(value));
  return value;
}
inline std::uint64_t to_bits(double value) {
  std::uint64_t bits;
  std::memcpy(&bits, &value, sizeof(bits));
  return bits;
}
static const std::uint64_t constants[] = {
  UINT64_C(0x40671547652b82fe), UINT64_C(0x3ce777d0ffda0d24), UINT64_C(0x408ef1584af17ecd), UINT64_C(0xc0513b4d4879e55e), UINT64_C(0x4114ffde7cc02cf4), UINT64_C(0x4118b31b87eb8904), UINT64_C(0x3d25e52272e0eaec)
};
static const std::uint64_t table[] = {
  UINT64_C(0x3ff0000000000000), UINT64_C(0x0000000000000000), UINT64_C(0x3ff0163da9fb3335), UINT64_C(0x3d13a4bc88ab6f0b),
  UINT64_C(0x3ff02c9a3e778060), UINT64_C(0x3d25448c4f3a3faa), UINT64_C(0x3ff04315e86e7f84), UINT64_C(0x3d20cea8d139df85),
  UINT64_C(0x3ff059b0d3158574), UINT64_C(0x3d04ca556a1b2fa8), UINT64_C(0x3ff0706b29ddf6dd), UINT64_C(0x3d2173b2871f2217),
  UINT64_C(0x3ff0874518759bc8), UINT64_C(0x3cd87a10f84f53b7), UINT64_C(0x3ff09e3ecac6f383), UINT64_C(0x3d0801b99f4f5b18),
  UINT64_C(0x3ff0b5586cf9890f), UINT64_C(0x3d1106d9ba253401), UINT64_C(0x3ff0cc922b7247f7), UINT64_C(0x3d06269675ff4e35),
  UINT64_C(0x3ff0e3ec32d3d1a2), UINT64_C(0x3cb62d2d983e6844), UINT64_C(0x3ff0fb66affed31a), UINT64_C(0x3d24935522e05558),
  UINT64_C(0x3ff11301d0125b50), UINT64_C(0x3d1bdebf5fb67959), UINT64_C(0x3ff12abdc06c31cb), UINT64_C(0x3d25245852cc8960),
  UINT64_C(0x3ff1429aaea92ddf), UINT64_C(0x3d1df748a567f8da), UINT64_C(0x3ff15a98c8a58e51), UINT64_C(0x3cf846f8d141b1d0),
  UINT64_C(0x3ff172b83c7d517a), UINT64_C(0x3d224349c9dfc205), UINT64_C(0x3ff18af9388c8de9), UINT64_C(0x3d1ee14f25e66832),
  UINT64_C(0x3ff1a35beb6fcb75), UINT64_C(0x3d03dd2c819e0908), UINT64_C(0x3ff1bbe084045cd3), UINT64_C(0x3d192b6b9f4c306a),
  UINT64_C(0x3ff1d4873168b9aa), UINT64_C(0x3d136c3949dfc34e), UINT64_C(0x3ff1ed5022fcd91c), UINT64_C(0x3d1db25aa6565c95),
  UINT64_C(0x3ff2063b88628cd6), UINT64_C(0x3d03118ae698d206), UINT64_C(0x3ff21f49917ddc96), UINT64_C(0x3cf7c551db68456f),
  UINT64_C(0x3ff2387a6e756238), UINT64_C(0x3d1045c6a6d3eecb), UINT64_C(0x3ff251ce4fb2a63f), UINT64_C(0x3d00db2bd14acf32),
  UINT64_C(0x3ff26b4565e27cdd), UINT64_C(0x3cf77bf4b6a48214), UINT64_C(0x3ff284dfe1f56380), UINT64_C(0x3d177f3dc394bd27),
  UINT64_C(0x3ff29e9df51fdee1), UINT64_C(0x3cfb5d8e0885ab1b), UINT64_C(0x3ff2b87fd0dad98f), UINT64_C(0x3d2390730108bc38),
  UINT64_C(0x3ff2d285a6e4030b), UINT64_C(0x3d03a1fee8c9225c), UINT64_C(0x3ff2ecafa93e2f56), UINT64_C(0x3ce5b2c9eff60911),
  UINT64_C(0x3ff306fe0a31b715), UINT64_C(0x3cfbd9046b69ea24), UINT64_C(0x3ff32170fc4cd831), UINT64_C(0x3d000e3e54fb7d75),
  UINT64_C(0x3ff33c08b26416ff), UINT64_C(0x3d06fc3180aac683), UINT64_C(0x3ff356c55f929ff0), UINT64_C(0x3d1e07c0017dfc4a),
  UINT64_C(0x3ff371a7373aa9ca), UINT64_C(0x3d18cb357ddac301), UINT64_C(0x3ff38cae6d05d865), UINT64_C(0x3d13ba556658c94d),
  UINT64_C(0x3ff3a7db34e59ff6), UINT64_C(0x3d212ee4dbdbae86), UINT64_C(0x3ff3c32dc313a8e4), UINT64_C(0x3d1345c8212d2278),
  UINT64_C(0x3ff3dea64c123422), UINT64_C(0x3cff31b9fb32e2e4), UINT64_C(0x3ff3fa4504ac801b), UINT64_C(0x3d17378cb7144a8a),
  UINT64_C(0x3ff4160a21f72e29), UINT64_C(0x3d21d4e28014ce07), UINT64_C(0x3ff431f5d950a896), UINT64_C(0x3d1f7ec78b0a541a),
  UINT64_C(0x3ff44e086061892d), UINT64_C(0x3cbbf96ee8afb9fb), UINT64_C(0x3ff46a41ed1d0057), UINT64_C(0x3d10283b91b051a3),
  UINT64_C(0x3ff486a2b5c13cd0), UINT64_C(0x3ce637bd8150db7d), UINT64_C(0x3ff4a32af0d7d3de), UINT64_C(0x3d0cd9f521d33a36),
  UINT64_C(0x3ff4bfdad5362a27), UINT64_C(0x3cf04715f70da237), UINT64_C(0x3ff4dcb299fddd0d), UINT64_C(0x3d0b942d586961a7),
  UINT64_C(0x3ff4f9b2769d2ca6), UINT64_C(0x3d17d36cccde36a5), UINT64_C(0x3ff516daa2cf6641), UINT64_C(0x3d1a6a7e10f26745),
  UINT64_C(0x3ff5342b569d4f81), UINT64_C(0x3d1e59e8ae6a99de), UINT64_C(0x3ff551a4ca5d920e), UINT64_C(0x3d1ab0010b956f3f),
  UINT64_C(0x3ff56f4736b527da), UINT64_C(0x3d0bb5c29f573dd8), UINT64_C(0x3ff58d12d497c7fd), UINT64_C(0x3cf3e81d7478cc39),
  UINT64_C(0x3ff5ab07dd485429), UINT64_C(0x3d07a560f05eeddb), UINT64_C(0x3ff5c9268a5946b7), UINT64_C(0x3cadfa723ae1bf17),
  UINT64_C(0x3ff5e76f15ad2148), UINT64_C(0x3d0d2407ce0f6433), UINT64_C(0x3ff605e1b976dc08), UINT64_C(0x3d171eb321c101b5),
  UINT64_C(0x3ff6247eb03a5584), UINT64_C(0x3d172ffea320da87), UINT64_C(0x3ff6434634ccc31f), UINT64_C(0x3d19d919a952ca95),
  UINT64_C(0x3ff6623882552224), UINT64_C(0x3d12b620c0998aac), UINT64_C(0x3ff68155d44ca973), UINT64_C(0x3cd0a350f225390e),
  UINT64_C(0x3ff6a09e667f3bcc), UINT64_C(0x3d126e8d1ea7de88), UINT64_C(0x3ff6c012750bdabe), UINT64_C(0x3d1e1e012931967d),
  UINT64_C(0x3ff6dfb23c651a2e), UINT64_C(0x3d1e8b028d2e51bb), UINT64_C(0x3ff6ff7df9519483), UINT64_C(0x3d1a098f71bcc9b0),
  UINT64_C(0x3ff71f75e8ec5f73), UINT64_C(0x3d1b984227e443e3), UINT64_C(0x3ff73f9a48a58173), UINT64_C(0x3d17807bd5e512c0),
  UINT64_C(0x3ff75feb564267c8), UINT64_C(0x3d17a16a40378bdb), UINT64_C(0x3ff780694fde5d3f), UINT64_C(0x3d07f77c42eaf147),
  UINT64_C(0x3ff7a11473eb0186), UINT64_C(0x3d1a5b034b27b244), UINT64_C(0x3ff7c1ed0130c132), UINT64_C(0x3d0e308095c8fab2),
  UINT64_C(0x3ff7e2f336cf4e62), UINT64_C(0x3cdfa03bd08bcda3), UINT64_C(0x3ff80427543e1a11), UINT64_C(0x3d15df63c009a845),
  UINT64_C(0x3ff82589994cce12), UINT64_C(0x3d10964d359847c9), UINT64_C(0x3ff8471a4623c7ac), UINT64_C(0x3d18857d98c4418d),
  UINT64_C(0x3ff868d99b4492ec), UINT64_C(0x3d0e78c3e7b184a0), UINT64_C(0x3ff88ac7d98a6699), UINT64_C(0x3d080f72957b0484),
  UINT64_C(0x3ff8ace5422aa0db), UINT64_C(0x3d056f6cd720fba3), UINT64_C(0x3ff8cf3216b5448b), UINT64_C(0x3d1bd0cf46f2f2b2),
  UINT64_C(0x3ff8f1ae99157736), UINT64_C(0x3cf42bc69235780f), UINT64_C(0x3ff9145b0b91ffc5), UINT64_C(0x3d0f715c3d56cd59),
  UINT64_C(0x3ff93737b0cdc5e4), UINT64_C(0x3d1bf4d1acf902db), UINT64_C(0x3ff95a44cbc8520e), UINT64_C(0x3d1a991ae1b50822),
  UINT64_C(0x3ff97d829fde4e4f), UINT64_C(0x3d0f9bcff58b04aa), UINT64_C(0x3ff9a0f170ca07b9), UINT64_C(0x3d14f656fe0ffb05),
  UINT64_C(0x3ff9c49182a3f090), UINT64_C(0x3ce984806660caa6), UINT64_C(0x3ff9e86319e32323), UINT64_C(0x3ce582eb35cac3f3),
  UINT64_C(0x3ffa0c667b5de564), UINT64_C(0x3d13c8ba7b0b1398), UINT64_C(0x3ffa309bec4a2d33), UINT64_C(0x3d038e88295250ef),
  UINT64_C(0x3ffa5503b23e255c), UINT64_C(0x3d0e84e556f025f4), UINT64_C(0x3ffa799e1330b358), UINT64_C(0x3d083bde4707301a),
  UINT64_C(0x3ffa9e6b5579fdbf), UINT64_C(0x3cfd72d3f1e40a93), UINT64_C(0x3ffac36bbfd3f379), UINT64_C(0x3d14cacf4c4b05e2),
  UINT64_C(0x3ffae89f995ad3ad), UINT64_C(0x3d0445b6038d7018), UINT64_C(0x3ffb0e07298db665), UINT64_C(0x3d0ed34583749cd0),
  UINT64_C(0x3ffb33a2b84f15fa), UINT64_C(0x3d1a2c7497c16670), UINT64_C(0x3ffb59728de55939), UINT64_C(0x3d0e0244cd9df3b7),
  UINT64_C(0x3ffb7f76f2fb5e46), UINT64_C(0x3d189f65d4b96070), UINT64_C(0x3ffba5b030a10649), UINT64_C(0x3d0b9006b1da3a39),
  UINT64_C(0x3ffbcc1e904bc1d2), UINT64_C(0x3cee4bb29d39c3a3), UINT64_C(0x3ffbf2c25bd71e08), UINT64_C(0x3d0b4338a23cfc57),
  UINT64_C(0x3ffc199bdd85529c), UINT64_C(0x3cec08f260a0042a), UINT64_C(0x3ffc40ab5fffd07a), UINT64_C(0x3d0647d6355e9b74),
  UINT64_C(0x3ffc67f12e57d14b), UINT64_C(0x3cfe1e92a1c04f0d), UINT64_C(0x3ffc8f6d9406e7b5), UINT64_C(0x3cdc920234dbf34d),
  UINT64_C(0x3ffcb720dcef9069), UINT64_C(0x3ce0e49a8304ef1f), UINT64_C(0x3ffcdf0b555dc3f9), UINT64_C(0x3d139e87e388d84e),
  UINT64_C(0x3ffd072d4a07897b), UINT64_C(0x3d0c0ae7070a6c51), UINT64_C(0x3ffd2f87080d89f1), UINT64_C(0x3d0b7531d7fbf731),
  UINT64_C(0x3ffd5818dcfba487), UINT64_C(0x3cedc682d68358e2), UINT64_C(0x3ffd80e316c98397), UINT64_C(0x3d1256cea656ebcd),
  UINT64_C(0x3ffda9e603db3285), UINT64_C(0x3d05e51917091778), UINT64_C(0x3ffdd321f301b460), UINT64_C(0x3cfd2ec7bfc90fd9),
  UINT64_C(0x3ffdfc97337b9b5e), UINT64_C(0x3d11d72cedf8d91c), UINT64_C(0x3ffe264614f5a128), UINT64_C(0x3d0ed88162f63e73),
  UINT64_C(0x3ffe502ee78b3ff6), UINT64_C(0x3cede1319abb2ae2), UINT64_C(0x3ffe7a51fbc74c83), UINT64_C(0x3cfc86cfb6cd46e4),
  UINT64_C(0x3ffea4afa2a490d9), UINT64_C(0x3d0926f89159b0a1), UINT64_C(0x3ffecf482d8e67f0), UINT64_C(0x3d0a89ed8a4d4206),
  UINT64_C(0x3ffefa1bee615a27), UINT64_C(0x3d063124664aaf80), UINT64_C(0x3fff252b376bba97), UINT64_C(0x3cfd19790d732ab4),
  UINT64_C(0x3fff50765b6e4540), UINT64_C(0x3d0309e68da0499f), UINT64_C(0x3fff7bfdad9cbe13), UINT64_C(0x3d091ff9e4e92cf9),
  UINT64_C(0x3fffa7c1819e90d8), UINT64_C(0x3cf0fa4931906b80), UINT64_C(0x3fffd3c22b8f71f1), UINT64_C(0x3ccb71923d729650),
};
inline double apple_current_exp(double x) {
  if (!(x >= 0.0 && x < 700.0)) return std::exp(x);
  const double inv_ln2_n = from_bits(constants[0]);
  const double inv_ln2_n_correction = from_bits(constants[1]);
  const double c0 = from_bits(constants[2]);
  const double c1 = from_bits(constants[3]);
  const double c2 = from_bits(constants[4]);
  const double c3 = from_bits(constants[5]);
  const double c4 = from_bits(constants[6]);
  const double q = x * inv_ln2_n;
  const std::int64_t k = static_cast<std::int64_t>(std::floor(q));
  const double kd = static_cast<double>(k);
  const double fraction = q - kd;
  const double multiply_error = std::fma(-x, inv_ln2_n, q);
  const double correction = std::fma(x, inv_ln2_n_correction, -multiply_error);
  const std::uint64_t index = static_cast<std::uint64_t>(k) & UINT64_C(0x7f);
  const double scale = from_bits(table[2 * index]);
  const double table_correction = from_bits(table[2 * index + 1]);
  const double r = fraction + (table_correction + correction);
  const double a = std::fma(r, fraction + c0, c2);
  const double b = std::fma(r, fraction + c1, c3);
  double p = r * c4;
  p *= a;
  p *= b;
  double result = std::fma(p, scale, scale);
  const std::int64_t exponent = k >> 7;
  std::uint64_t result_bits = to_bits(result);
  result_bits += static_cast<std::uint64_t>(exponent) << 52U;
  return from_bits(result_bits);
}
}  // namespace sct_compat
#endif

