/* Portable arithmetic reconstructed from the active macOS arm64e
 * libsystem_m log10 routine. The lookup-table bytes are preserved exactly.
 */
#ifndef SCT_APPLE_CURRENT_LOG10_COMPAT_H
#define SCT_APPLE_CURRENT_LOG10_COMPAT_H
#include <cmath>
#include <cstdint>
#include <cstring>
namespace sct_compat {
inline double log10_from_bits(std::uint64_t bits) {
  double value;
  std::memcpy(&value, &bits, sizeof(value));
  return value;
}
inline std::uint64_t log10_to_bits(double value) {
  std::uint64_t bits;
  std::memcpy(&bits, &value, sizeof(bits));
  return bits;
}
static const std::uint64_t log10_table[] = {
  UINT64_C(0x3ff0000000000000), UINT64_C(0x0000000000000000),
  UINT64_C(0x3fefc07f01fb38d4), UINT64_C(0x3f6bafd4727c9364),
  UINT64_C(0x3fef81f81f81a3e5), UINT64_C(0x3f7b9476a50f6475),
  UINT64_C(0x3fef44659e49d2b1), UINT64_C(0x3f849b085150a16d),
  UINT64_C(0x3fef07c1f07c3108), UINT64_C(0x3f8b5e908eaf3398),
  UINT64_C(0x3feecc07b3017601), UINT64_C(0x3f910a83a84b1f39),
  UINT64_C(0x3fee9131abf09b55), UINT64_C(0x3f945f4f5acd2447),
  UINT64_C(0x3fee573ac902a11f), UINT64_C(0x3f97adc3df306138),
  UINT64_C(0x3fee1e1e1e1e0ae1), UINT64_C(0x3f9af5f92b020224),
  UINT64_C(0x3fede5d6e3f7cbaf), UINT64_C(0x3f9e3806acc7e0f9),
  UINT64_C(0x3fedae6076b8f76b), UINT64_C(0x3fa0ba01a81b0d1d),
  UINT64_C(0x3fed77b654b7b0b1), UINT64_C(0x3fa25502c0ffd549),
  UINT64_C(0x3fed41d41d410288), UINT64_C(0x3fa3ed1199ac1d02),
  UINT64_C(0x3fed0cb58f6e27bc), UINT64_C(0x3fa58238eeb7e4d6),
  UINT64_C(0x3fecd8568902fb3f), UINT64_C(0x3fa714834281fa6c),
  UINT64_C(0x3feca4b3055ed9ba), UINT64_C(0x3fa8a3fadeb884d0),
  UINT64_C(0x3fec71c71c70f481), UINT64_C(0x3faa30a9d6105e4b),
  UINT64_C(0x3fec3f8f01c3ce79), UINT64_C(0x3fabba9a058f4bc9),
  UINT64_C(0x3fec0e0703826caa), UINT64_C(0x3fad41d5164a5b23),
  UINT64_C(0x3febdd2b89930e8e), UINT64_C(0x3faec6647ebd4665),
  UINT64_C(0x3febacf914c177b9), UINT64_C(0x3fb02428c1f18d98),
  UINT64_C(0x3feb7d6c3dd95825), UINT64_C(0x3fb0e3d29d848db3),
  UINT64_C(0x3feb4e81b4e7b01f), UINT64_C(0x3fb1a2344551cc7e),
  UINT64_C(0x3feb2036406badd7), UINT64_C(0x3fb25f5215eeba23),
  UINT64_C(0x3feaf286bca2397c), UINT64_C(0x3fb31b3055c23663),
  UINT64_C(0x3feac5701ac4d7c0), UINT64_C(0x3fb3d5d335c7aa31),
  UINT64_C(0x3fea98ef60696bd7), UINT64_C(0x3fb48f3ed1e3553a),
  UINT64_C(0x3fea6d01a6cfc64f), UINT64_C(0x3fb547773198a06b),
  UINT64_C(0x3fea41a41a40b6e9), UINT64_C(0x3fb5fe80488ee159),
  UINT64_C(0x3fea16d3f97b18da), UINT64_C(0x3fb6b45df6f07593),
  UINT64_C(0x3fe9ec8e95113011), UINT64_C(0x3fb769140a20ed4f),
  UINT64_C(0x3fe9c2d14ee59e3b), UINT64_C(0x3fb81ca63d015f6c),
  UINT64_C(0x3fe9999999992278), UINT64_C(0x3fb8cf1838884d6e),
  UINT64_C(0x3fe970e4f80c4ba4), UINT64_C(0x3fb9806d94167d88),
  UINT64_C(0x3fe948b0fcd69907), UINT64_C(0x3fba30a9d60b536d),
  UINT64_C(0x3fe920fb49d1de51), UINT64_C(0x3fbadfd074126264),
  UINT64_C(0x3fe8f9c18f9b4e11), UINT64_C(0x3fbb8de4d3aec4d9),
  UINT64_C(0x3fe8d3018d2f1d8b), UINT64_C(0x3fbc3aea4a60d466),
  UINT64_C(0x3fe8acb90f6c68a1), UINT64_C(0x3fbce6e41e442e9e),
  UINT64_C(0x3fe886e5f0abeab2), UINT64_C(0x3fbd91d58669a0d9),
  UINT64_C(0x3fe861861862484b), UINT64_C(0x3fbe3bc1ab0aa46f),
  UINT64_C(0x3fe83c977ab327e6), UINT64_C(0x3fbee4aba60f1033),
  UINT64_C(0x3fe8181818173ae4), UINT64_C(0x3fbf8c96834a7e48),
  UINT64_C(0x3fe7f405fd00d922), UINT64_C(0x3fc019c2a066360c),
  UINT64_C(0x3fe7d05f417c0774), UINT64_C(0x3fc06cbd67a915cd),
  UINT64_C(0x3fe7ad2208e0dbe0), UINT64_C(0x3fc0bf3d0937ebc3),
  UINT64_C(0x3fe78a4c81784397), UINT64_C(0x3fc11142f081f8db),
  UINT64_C(0x3fe767dce433bafd), UINT64_C(0x3fc162d082aed3fe),
  UINT64_C(0x3fe745d1745de7ba), UINT64_C(0x3fc1b3e71ec75d90),
  UINT64_C(0x3fe724287f468d6d), UINT64_C(0x3fc204881def4ac9),
  UINT64_C(0x3fe702e05c0c18e3), UINT64_C(0x3fc254b4d35d0f5f),
  UINT64_C(0x3fe6e1f76b42428f), UINT64_C(0x3fc2a46e8caa0de1),
  UINT64_C(0x3fe6c16c16c06c9b), UINT64_C(0x3fc2f3b691c81020),
  UINT64_C(0x3fe6a13cd1528b5e), UINT64_C(0x3fc3428e2542415b),
  UINT64_C(0x3fe681681681a1f6), UINT64_C(0x3fc390f684497c90),
  UINT64_C(0x3fe661ec6a5049d6), UINT64_C(0x3fc3def0e6e1face),
  UINT64_C(0x3fe642c8590aa5ef), UINT64_C(0x3fc42c7e7fe5304e),
  UINT64_C(0x3fe623fa7701094f), UINT64_C(0x3fc479a07d3c4360),
  UINT64_C(0x3fe605816057fe92), UINT64_C(0x3fc4c65807e96e6b),
  UINT64_C(0x3fe5e75bb8cfdcfb), UINT64_C(0x3fc512a64429fcb4),
  UINT64_C(0x3fe5c9882b922e81), UINT64_C(0x3fc55e8c518d5130),
  UINT64_C(0x3fe5ac056b01183e), UINT64_C(0x3fc5aa0b4b0a3393),
  UINT64_C(0x3fe58ed230825723), UINT64_C(0x3fc5f5244722cd0f),
  UINT64_C(0x3fe571ed3c514831), UINT64_C(0x3fc63fd857fa0cf1),
  UINT64_C(0x3fe555555555be48), UINT64_C(0xbfbffbfc2bbe9af4),
  UINT64_C(0x3fe5390948f33af7), UINT64_C(0xbfbf68216c986b90),
  UINT64_C(0x3fe51d07eae25fe5), UINT64_C(0xbfbed50a4a23c997),
  UINT64_C(0x3fe501501501bd58), UINT64_C(0xbfbe42b4c16eed44),
  UINT64_C(0x3fe4e5e0a72ea8ca), UINT64_C(0xbfbdb11ed764c030),
  UINT64_C(0x3fe4cab88726a83c), UINT64_C(0xbfbd204698d07526),
  UINT64_C(0x3fe4afd6a051e80f), UINT64_C(0xbfbc902a19e1cbfd),
  UINT64_C(0x3fe49539e3b27047), UINT64_C(0xbfbc00c776701e92),
  UINT64_C(0x3fe47ae147ad26e5), UINT64_C(0xbfbb721cd16c4e1c),
  UINT64_C(0x3fe460cbc7f6ce28), UINT64_C(0xbfbae428550f01d9),
  UINT64_C(0x3fe446f8656250ca), UINT64_C(0xbfba56e8325c6c50),
  UINT64_C(0x3fe42d6625d45a4e), UINT64_C(0xbfb9ca5aa16e608d),
  UINT64_C(0x3fe4141414137fce), UINT64_C(0xbfb93e7de0f90978),
  UINT64_C(0x3fe3fb013fb1102f), UINT64_C(0xbfb8b3503651ddb3),
  UINT64_C(0x3fe3e22cbce5a6b7), UINT64_C(0xbfb828cfed2f2caf),
  UINT64_C(0x3fe3c995a47afe53), UINT64_C(0xbfb79efb57ad28ba),
  UINT64_C(0x3fe3b13b13b04947), UINT64_C(0xbfb715d0ce3125d3),
  UINT64_C(0x3fe3991c2c17b662), UINT64_C(0xbfb68d4eaf2263a3),
  UINT64_C(0x3fe3813813803a55), UINT64_C(0xbfb605735ee3df92),
  UINT64_C(0x3fe3698df3de9d20), UINT64_C(0xbfb57e3d47c709af),
  UINT64_C(0x3fe3521cfb2b1096), UINT64_C(0xbfb4f7aad9b97441),
  UINT64_C(0x3fe33ae45b573065), UINT64_C(0xbfb471ba8a7ab790),
  UINT64_C(0x3fe323e34a2baef3), UINT64_C(0xbfb3ec6ad5440f5a),
  UINT64_C(0x3fe30d190131cd5b), UINT64_C(0xbfb367ba3aafd5ee),
  UINT64_C(0x3fe2f684bda0a126), UINT64_C(0xbfb2e3a740b43dff),
  UINT64_C(0x3fe2e025c04c5430), UINT64_C(0xbfb2603072a73dd8),
  UINT64_C(0x3fe2c9fb4d8060d5), UINT64_C(0xbfb1dd5460c3fb8b),
  UINT64_C(0x3fe2b404ad01d56c), UINT64_C(0xbfb15b11a098953a),
  UINT64_C(0x3fe29e4129e3187d), UINT64_C(0xbfb0d966cc5f2b50),
  UINT64_C(0x3fe288b012898ed6), UINT64_C(0xbfb05852837b79c2),
  UINT64_C(0x3fe27350b881d871), UINT64_C(0xbfafafa6d3a047d3),
  UINT64_C(0x3fe25e22707fbbf8), UINT64_C(0xbfaeafd0502b92c7),
  UINT64_C(0x3fe249249249e9cf), UINT64_C(0xbfadb11ed7700a68),
  UINT64_C(0x3fe23456789bb267), UINT64_C(0xbfacb38fcce476e8),
  UINT64_C(0x3fe21fb781227951), UINT64_C(0xbfabb7209d242ce5),
  UINT64_C(0x3fe20b470c676cac), UINT64_C(0xbfaabbcebd80ef57),
  UINT64_C(0x3fe1f7047dc1c36b), UINT64_C(0xbfa9c197abf7fb7a),
  UINT64_C(0x3fe1e2ef3b3fd2c9), UINT64_C(0xbfa8c878eeb197cb),
  UINT64_C(0x3fe1cf06ada1ee29), UINT64_C(0xbfa7d070145824fe),
  UINT64_C(0x3fe1bb4a4045ee1f), UINT64_C(0xbfa6d97ab3addfcf),
  UINT64_C(0x3fe1a7b961199740), UINT64_C(0xbfa5e3966b7356cb),
  UINT64_C(0x3fe19453808caf9f), UINT64_C(0xbfa4eec0e24633c5),
  UINT64_C(0x3fe181181181a457), UINT64_C(0xbfa3faf7c669fbf0),
  UINT64_C(0x3fe16e0689430a4c), UINT64_C(0xbfa30838cdca801e),
  UINT64_C(0x3fe15b1e5f74ca8f), UINT64_C(0xbfa21681b5c42118),
  UINT64_C(0x3fe1485f0e0bc882), UINT64_C(0xbfa125d0433b42f6),
  UINT64_C(0x3fe135c81135efed), UINT64_C(0xbfa0362241e83be8),
  UINT64_C(0x3fe12358e75dd419), UINT64_C(0xbf9e8eeb0a0393c4),
  UINT64_C(0x3fe1111111104099), UINT64_C(0xbf9cb38fccc387a4),
  UINT64_C(0x3fe0fef010fe3855), UINT64_C(0xbf9ada2e8e2b8ccc),
  UINT64_C(0x3fe0ecf56be75b6e), UINT64_C(0xbf9902c31d763f47),
  UINT64_C(0x3fe0db20a89031a0), UINT64_C(0xbf972d4956e25992),
  UINT64_C(0x3fe0c9714fbdd2a2), UINT64_C(0xbf9559bd2420786b),
  UINT64_C(0x3fe0b7e6ec259ec9), UINT64_C(0xbf93881a7b81aa5e),
  UINT64_C(0x3fe0a6810a68f2a2), UINT64_C(0xbf91b85d605c7d78),
  UINT64_C(0x3fe0953f3900460b), UINT64_C(0xbf8fd503c36764ef),
  UINT64_C(0x3fe084210841501d), UINT64_C(0xbf8c3d08374fd2e0),
  UINT64_C(0x3fe073260a48f47f), UINT64_C(0xbf88a8c06be7337e),
  UINT64_C(0x3fe0624dd2f253e0), UINT64_C(0xbf851824c77c8587),
  UINT64_C(0x3fe05197f7d73005), UINT64_C(0xbf818b2dc8d1e1bf),
  UINT64_C(0x3fe04104104183ee), UINT64_C(0xbf7c03a80b1c8a49),
  UINT64_C(0x3fe03091b51e60a3), UINT64_C(0xbf74f82051c84636),
  UINT64_C(0x3fe0204081017ac2), UINT64_C(0xbf6be76bd7050239),
  UINT64_C(0x3fe01010100fc088), UINT64_C(0xbf5bd96a1cf3fdd8),
  UINT64_C(0x3fe0000000000000), UINT64_C(0x0000000000000000),
};
inline double apple_current_log10(double input) {
  const std::uint64_t input_bits = log10_to_bits(input);
  const std::uint64_t normal_check = input_bits - UINT64_C(0x0010000000000000);
  if (normal_check >= UINT64_C(0x7fe0000000000000)) return std::log10(input);
  const std::int64_t exponent = static_cast<std::int64_t>(
    input_bits + UINT64_C(0xc018100000000000)
  ) >> 52;
  const std::uint64_t mantissa = input_bits & UINT64_C(0x000fffffffffffff);
  const std::uint64_t index =
    (mantissa + UINT64_C(0x0000100000000000)) >> 45;
  const double z = log10_from_bits(mantissa | UINT64_C(0x3ff0000000000000));
  const double inverse_center = log10_from_bits(log10_table[2 * index]);
  const double log10_center = log10_from_bits(log10_table[2 * index + 1]);
  const double c0 = log10_from_bits(UINT64_C(0xbfb49704e9bc168e));
  const double c1 = log10_from_bits(UINT64_C(0x3fafc431f82b9b9d));
  const double c2 = log10_from_bits(UINT64_C(0x3ff9de61616cdf2b));
  const double c3 = log10_from_bits(UINT64_C(0x3ff609d14c7ee9be));
  const double c4 = log10_from_bits(UINT64_C(0x3ffab7d4f0547db7));
  const double c5 = log10_from_bits(UINT64_C(0xbff3f6ab6ec10818));
  const double reduced = std::fma(z, inverse_center, -1.0);
  const double factor0 = std::fma(reduced, c1, c0);
  const double factor1 = std::fma(reduced, reduced + c3, c2);
  const double factor2 = std::fma(reduced, reduced + c5, c4);
  double polynomial = reduced * reduced;
  polynomial *= factor0;
  polynomial *= factor1;
  polynomial *= factor2;
  const double inv_ln10 = log10_from_bits(UINT64_C(0x3fdbcb7b1526e50e));
  if (exponent != 0) {
    const double log10_2_high = log10_from_bits(UINT64_C(0x3fd3441350000000));
    const double log10_2_low = log10_from_bits(UINT64_C(0x3e03ef3fde623e25));
    const double table_high = log10_from_bits(
      log10_to_bits(log10_center) & UINT64_C(0xfffffffff8000000)
    );
    double table_low = log10_center - table_high;
    table_low += polynomial;
    const double exponent_double = static_cast<double>(exponent);
    const double high = std::fma(exponent_double, log10_2_high, table_high);
    double low = exponent_double * log10_2_low;
    low += reduced * inv_ln10;
    low += table_low;
    return high + low;
  }
  const double product = inverse_center * z;
  const double product_minus_one = product - 1.0;
  const double product_error = std::fma(inverse_center, z, -product);
  const double inv_ln10_high = log10_from_bits(UINT64_C(0x3fdbcb7b18000000));
  const double inv_ln10_low = log10_from_bits(UINT64_C(0xbe26c8d78e6acaa4));
  const double reduced_high = log10_from_bits(
    log10_to_bits(reduced) & UINT64_C(0xfffffffff8000000)
  );
  const double reduced_low = product_error + (product_minus_one - reduced_high);
  const double scaled_high = reduced_high * inv_ln10_high;
  double high = log10_center + scaled_high;
  const double high_rounding_error = scaled_high - (high - log10_center);
  double low = std::fma(reduced_low, inv_ln10_high, reduced * inv_ln10_low);
  low += high_rounding_error;
  low += polynomial;
  return high + low;
}
}  // namespace sct_compat
#endif
